﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace graphicss
{
    public partial class Form2 : Form
    {

       
        private bool isRunning;
        public Form2()
        {
            rnd = new Random();
            isRunning = false;
            InitializeComponent();
            
        }
        List<Pen> bru = new List<Pen>();
        Random rnd = new Random();

        private void кругToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            g.Clear(Color.White);
            Pen redPen = new Pen(Color.Red, 3);
            Brush brush=new SolidBrush(Color.Blue);
            g.DrawEllipse(redPen, 50, 50, 50, 50);
            g.FillEllipse(brush, 120, 50, 50, 50);
            Brush outerBrush = new SolidBrush(Color.Red);
            Brush innerBrush = new SolidBrush(Color.Blue);
            int x = 100;
            int y = 150;
            for (int i = 0; i <= 50; i += 10)
            {
                g.DrawEllipse(bru[rnd.Next(0, bru.Count)], x, y, i, i);
                x -= 5;
                y -= 5;
            }
        }

        private void квадратToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            g.Clear(Color.White); 

            Pen redPen = new Pen(Color.Red, 3);
            Brush brush = new SolidBrush(Color.Blue);
            g.DrawRectangle(redPen, 50, 50, 50, 50);
            g.FillRectangle(brush, 120, 50, 50, 50);
            Brush outerBrush = new SolidBrush(Color.Red);
            Brush innerBrush = new SolidBrush(Color.Blue);
            int x = 100;
            int y = 150;
            for (int i = 0; i <= 50; i += 10)
            {
                g.DrawRectangle(bru[rnd.Next(0, bru.Count)], x, y, i, i);
                x -= 5;
                y -= 5;
            }
        }

        private void овалToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            g.Clear(Color.White);
            Pen redPen = new Pen(Color.Red, 3);
            Brush brush = new SolidBrush(Color.Blue);
            g.DrawEllipse(redPen, 50, 50, 60, 50);
            g.FillEllipse(brush, 120, 50, 60, 50);
           
            Brush outerBrush = new SolidBrush(Color.Red);
            Brush innerBrush = new SolidBrush(Color.Blue);
            int x = 100;
            int y = 150;
            for (int i = 0; i <= 50; i += 10)
            {
                g.DrawEllipse(bru[rnd.Next(0,bru.Count)], x, y, i+10, i);
                x -= 5;
                y -= 5;
            }
        }

        private void прямоугольникToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            g.Clear(Color.White);

            Pen redPen = new Pen(Color.Red, 3);
            Brush brush = new SolidBrush(Color.Blue);
            g.DrawRectangle(redPen, 50, 50, 70, 50);
            g.FillRectangle(brush, 140, 50, 70, 50);
            Brush outerBrush = new SolidBrush(Color.Red);
            Brush innerBrush = new SolidBrush(Color.Blue);
            int x = 100;
            int y = 150;
            for (int i = 0; i <= 50; i += 10)
            {
                g.DrawRectangle(bru[rnd.Next(0, bru.Count)], x, y, i+20, i);
                x -= 5;
                y -= 5;
            }
           
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
            Pen r = new Pen(Color.Red, 3);
            Pen g = new Pen(Color.Green, 3);
            Pen b = new Pen(Color.Blue, 3);
            Pen p = new Pen(Color.Purple, 3);
            Pen redPen = new Pen(Color.Black, 3);
            Pen brown = new Pen(Color.Brown, 3);
            Pen orangePen = new Pen(Color.Orange, 3);
            bru.Add(b);
            bru.Add(r);
            bru.Add(g);
            bru.Add(p);
            bru.Add(redPen);
            bru.Add(orangePen);
            bru.Add(brown);


        }

        private void снеговикToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

            Graphics graphics = this.CreateGraphics();
            Brush brush = new SolidBrush(Color.Black);
            graphics.Clear(Color.White);
            graphics.DrawEllipse(bru[4], 150, 100, 100, 100);
            graphics.DrawEllipse(bru[4], 135, 200, 130, 130);
            graphics.DrawEllipse(bru[4], 120, 330, 160, 160);
            graphics.FillEllipse(brush, 170, 150, 10, 10);
            graphics.FillEllipse(brush, 210, 150, 10, 10);
            Point[] nosePoints = { new Point(195, 165), new Point(195, 175), new Point(97, 170) };
            graphics.FillPolygon(Brushes.Orange, nosePoints);
            Point[] hatPoints = { new Point(120, 120), new Point(280, 120), new Point(200, 30), new Point(200, 30) };
            graphics.FillPolygon(Brushes.SkyBlue, hatPoints);

            graphics.FillRectangle(Brushes.Brown, 535, 400, 30, 60);
            graphics.FillRectangle(Brushes.Brown, 688, 340, 40, 60);
            graphics.FillRectangle(Brushes.Brown, 435, 290, 30, 60);
            Point[] elka = { new Point(500, 400), new Point(600, 400), new Point(550, 200) };
            graphics.FillPolygon(Brushes.LightGreen, elka);
            Point[] elka1 = { new Point(400, 300), new Point(500, 300), new Point(450, 70) };
            graphics.FillPolygon(Brushes.LightGreen, elka1);
            Point[] elka2 = { new Point(630, 350), new Point(790, 350), new Point(705, 70) };
            graphics.FillPolygon(Brushes.LightGreen, elka2);


            graphics.Dispose();



        }

        private Point startPoint;
        private Point endPoint;

        private void эЩКЕРЕToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void з5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = true;
            pictureBox1.Visible = true;
        }

        private void Form2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                endPoint = e.Location;
            }
            this.Invalidate();
        }

        private void Form2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                startPoint = e.Location;
            }
        }
        

        public System.Windows.Forms.Timer timer;
        
        public Point[] drops;
        public int dropSize;

        private void Form2_Paint(object sender, PaintEventArgs e)
        {
            if (startPoint != null && endPoint != null)
            {
                e.Graphics.DrawLine(Pens.Black, startPoint, endPoint);
            }
           
        }

        


        private void button1_Click(object sender, EventArgs e)
        {
            if (!isRunning)
            {
                isRunning = true;
               
                timer1.Start();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (isRunning)
            {
                isRunning = false;
                timer1.Stop();
            }
        }

        

        private void timer1_Tick(object sender, EventArgs e)
        {
           
                Graphics g = pictureBox1.CreateGraphics();
                Pen pen = new Pen(Color.Blue);
                int x = rnd.Next(pictureBox1.Width);
                int y = 0;

                while (isRunning)
                {
                  for (int i = 0; i < 10; i++)
                  {
                    g.DrawLine(pen, x, y, x, y + 10);
                    y += 10;
                    i++;
                  }

                if (y >= pictureBox1.Height)
                {
                    x = rnd.Next(pictureBox1.Width);
                    y = 0;
                }
               

                    Thread.Sleep(15);
                    g.Clear(Color.White);
                }


                g.Dispose();
            }
        }
    }

