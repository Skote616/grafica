﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace graphicss
{
    public partial class Form1 : Form
    {
        private Point startPoint;
        private Point endPoint;
        public Form1()
        {
            InitializeComponent();
            InitializeRainEffect();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            Pen redPen = new Pen(Color.Red, 3);
            g.DrawLine(redPen, 140, 170, 140, 230);
            g.DrawRectangle(redPen, 50, 60, 50, 60);
            g.DrawEllipse(redPen, 150, 100, 100, 60);
            g.Dispose(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            float x0, y0, x1, y1, x2, y2;
            g = this.CreateGraphics();
            g.Clear(Color.White);
            Pen myPen = new Pen(Color.BlueViolet);
            g.DrawLine(Pens.Black, this.Width / 2f, 0, this.Width / 2f, this.Height);
            g.DrawLine(Pens.Black, 0, this.Height / 2f, this.Width, this.Height /2f);
            x0 = this.Width / 2;
            y0 = this.Height / 2;

            x1 = -1230;
            y1 = 1000 / x1;
            for (int i = -1229; i < 1230; i++)
            {
                if (i != 0)
                {
                    x2 = i;
                    y2 = 1000 / x2;
                    g.DrawLine(myPen, (x1 + x0), (-y1 + y0), x2 + x0, (-y2 + y0));
                    x1 = x2;
                    y1 = y2;
                }
            }
            g.Dispose();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int x = 0;
            int y = 0;
            int dx = 25;
            int dy = 25;
            Graphics g = this.CreateGraphics();
            Pen redPen = new Pen(Color.Red, 3);

            for (int i = 0; i < 1000; i++)
            {
                g.DrawEllipse(redPen, x, y, 60, 60);
                Thread.Sleep(100);
                g.Clear(Color.White);


                if (x + dx < 0 || x + dx > this.Width - 78)
                {
                    dx = -dx;
                }
                if (y + dy < 0 || y + dy > this.Height - 90)
                {
                    dy = -dy;
                }

                x += dx;
                y += dy;
            }

            g.Dispose();

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            int x = 100;
            int y = 40;
            int dx = 10;
            int dy = 10;
            Graphics g = this.CreateGraphics();
            Pen redPen = new Pen(Color.Red, 3);

            for (int i = 0; i < 1000; i++)
            {
                g.DrawEllipse(redPen, x, y, 20, 20);
                Thread.Sleep(100);
                g.Clear(Color.White);


                if (x + dx < 0 || x + dx > this.Width - 30)
                {
                    dx = -dx;
                }
                if (y + dy < 0 || y + dy > this.Height - 50)
                {
                    dy = -dy;
                }

                x += dx;
                y += dy;
            }

            g.Dispose();
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            using (Brush brush = new SolidBrush(Color.Blue))
            {
                foreach (Point drop in drops)
                {
                    e.Graphics.FillRectangle(brush, drop.X, drop.Y, dropSize, dropSize);
                }
            }
        }


        public System.Windows.Forms.Timer timer;
        public Random random;
        public Point[] drops;
        public int dropSize;


        private void InitializeRainEffect()
        {
            random = new Random();
            dropSize = 3;
            drops = new Point[20];
            System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
            timer.Interval = 30;
            timer.Tick += timer1_Tick_1;
            timer.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            for (int i = 0; i < drops.Length; i++)
            {
                drops[i].Y += 10;
                if (drops[i].Y > this.Height)
                {

                    drops[i] = new Point(random.Next(this.Width), 0);
                }
            }
        }
    }
}
